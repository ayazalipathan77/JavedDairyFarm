====================================
   JAVED DAIRY FARM - OFFLINE APP
====================================

✅ CHROME COMPATIBLE VERSION!
This version works in ALL browsers including Chrome!

HOW TO USE:
-----------
1. Extract all files from the zip to a folder on your computer
2. Double-click on "index.html" to open the app
3. Works in Chrome, Firefox, Edge, Safari - NO SERVER NEEDED!
4. The app works completely offline - no internet needed!

THAT'S IT! Just double-click index.html and it works!

FEATURES:
---------
✓ Dashboard with daily statistics
✓ Daily milk entry tracking
✓ Customer management
✓ Monthly billing & reports
✓ Cash ledger & transactions
✓ Backup & restore data

DATA STORAGE:
-------------
- All data is stored locally in your browser
- Data persists between sessions
- Use Settings > Backup to export your data
- Keep regular backups of your data!

BROWSER SUPPORT:
----------------
✓ Firefox (Best for offline use)
✓ Microsoft Edge
✓ Chrome (needs local server)
✓ Safari

TIPS:
-----
• Bookmark the page for easy access
• Use "Save All" button daily to ensure data is saved
• Export backup regularly from Settings page
• Data is separate for each browser

DEFAULT LOGIN:
--------------
Role: ADMIN (full access)
You can switch roles in Settings if needed.

TROUBLESHOOTING:
----------------
Problem: Blank white screen
Solution: Make sure all files are extracted together in the same folder

Problem: "Failed to load" errors
Solution: Use Firefox or run a local server (see METHOD 1 above)

Problem: Data disappeared
Solution: Don't clear browser data. Use backup/restore feature!

SUPPORT:
--------
For any issues, contact the developer.

Version: 1.0
Built: January 2026
