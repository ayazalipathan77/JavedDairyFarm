#!/bin/bash

echo "========================================"
echo "  JAVED DAIRY FARM - LOCAL SERVER"
echo "========================================"
echo ""
echo "Starting local web server..."
echo ""
echo "Open this URL in your browser:"
echo "http://localhost:8080"
echo ""
echo "Press Ctrl+C to stop the server when done."
echo ""
echo "========================================"
echo ""

# Try to open browser automatically
if command -v xdg-open > /dev/null; then
    xdg-open "http://localhost:8080" 2>/dev/null &
elif command -v open > /dev/null; then
    open "http://localhost:8080" 2>/dev/null &
fi

# Start Python server
if command -v python3 > /dev/null; then
    echo "Using Python 3..."
    python3 -m http.server 8080
elif command -v python > /dev/null; then
    echo "Using Python..."
    python -m http.server 8080
else
    echo ""
    echo "ERROR: Python is not installed!"
    echo ""
    echo "Please install Python or open index.html in Firefox."
    echo ""
fi
